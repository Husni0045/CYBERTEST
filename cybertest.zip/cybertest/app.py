from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash
from pymongo import MongoClient
import random
import json
from datetime import datetime
from bson import ObjectId
import os
from datetime import timedelta
from werkzeug.security import generate_password_hash, check_password_hash
import time

app = Flask(__name__)
# Use a SECRET from env in production. Falling back to a value here only for local dev.
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'dev-secret-key-please-change')

# Simple admin credentials (change for production). Prefer setting secure secrets in environment.
ADMIN_USERNAME = os.environ.get('CYBER_ADMIN_USER', 'admin')
_raw_admin_pass = os.environ.get('CYBER_ADMIN_PASS', 'admin123')
# If the provided admin password looks already hashed (werkzeug PBKDF2), accept it; otherwise hash it in-memory.
if isinstance(_raw_admin_pass, str) and _raw_admin_pass.startswith('pbkdf2:'):
    ADMIN_PASSWORD_HASH = _raw_admin_pass
else:
    ADMIN_PASSWORD_HASH = generate_password_hash(_raw_admin_pass)

# Session and security settings
app.config.update({
    'SESSION_COOKIE_SECURE': True,      # require HTTPS for cookies (set to True in prod)
    'SESSION_COOKIE_HTTPONLY': True,
    'SESSION_COOKIE_SAMESITE': 'Lax',
    'PERMANENT_SESSION_LIFETIME': timedelta(minutes=30)
})

# Simple in-memory login attempt tracker (per-IP). For production use a shared store like Redis.
LOGIN_ATTEMPTS = {}
LOGIN_WINDOW = 600  # seconds to track (10 minutes)
LOGIN_MAX_ATTEMPTS = 6
ALLOWED_VERSIONS = ["12", "11", "10", "9", "8"]

# MongoDB Atlas Connection
client = MongoClient("mongodb+srv://admin:admin123@cluster0.2mcmdvo.mongodb.net/?retryWrites=true&w=majority")
db = client["cybertest_db"]
collection = db["questions"]

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/about')
def about():
    return render_template('about.html')


# ---------- Admin auth and question add routes ----------
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = (request.form.get('username') or '').strip()
        password = (request.form.get('password') or '').strip()

        # simple rate limit per IP
        ip = request.remote_addr or 'unknown'
        now = time.time()
        attempts = LOGIN_ATTEMPTS.get(ip, [])
        # purge old
        attempts = [t for t in attempts if now - t < LOGIN_WINDOW]
        if len(attempts) >= LOGIN_MAX_ATTEMPTS:
            flash('Too many login attempts. Try again later.', 'error')
            return redirect(url_for('admin_login'))

        # validate credentials using hashed password
        if username == ADMIN_USERNAME and check_password_hash(ADMIN_PASSWORD_HASH, password):
            session.permanent = True
            session['admin'] = True
            # reset attempts on success
            LOGIN_ATTEMPTS.pop(ip, None)
            flash('Logged in as admin', 'success')
            return redirect(url_for('add_question'))
        else:
            # record failed attempt
            attempts.append(now)
            LOGIN_ATTEMPTS[ip] = attempts
            flash('Invalid credentials', 'error')
            return redirect(url_for('admin_login'))
    return render_template('admin_login.html')


@app.route('/admin/logout')
def admin_logout():
    session.pop('admin', None)
    flash('Logged out', 'info')
    return redirect(url_for('index'))


@app.route('/admin/add_question', methods=['GET', 'POST'])
def add_question():
    # require admin
    if not session.get('admin'):
        return redirect(url_for('admin_login'))

    if request.method == 'POST':
        # Gather and sanitize inputs
        version = (request.form.get('version') or '').strip()
        question_text = (request.form.get('question') or '').strip()
        raw_opts = [request.form.get('opt1'), request.form.get('opt2'), request.form.get('opt3'), request.form.get('opt4')]
        # Normalize options: remove empty/whitespace-only entries
        options = [o.strip() for o in (raw_opts or []) if o and o.strip()]
        correct = (request.form.get('correct') or '').strip()
        topic = (request.form.get('topic') or '').strip()

        # Server-side validation
        if not version or version not in ALLOWED_VERSIONS:
            flash('Please select a valid version.', 'error')
            return redirect(url_for('add_question'))
        if not question_text or len(question_text) < 10:
            flash('Please provide a longer question text (at least 10 characters).', 'error')
            return redirect(url_for('add_question'))
        if len(options) < 2:
            flash('Please provide at least two non-empty options.', 'error')
            return redirect(url_for('add_question'))
        if not correct:
            flash('Please select the correct option.', 'error')
            return redirect(url_for('add_question'))
        if correct not in options:
            flash('The correct option must match one of the provided options.', 'error')
            return redirect(url_for('add_question'))

        # Prevent exact duplicate question for same version
        existing = collection.find_one({'version': version, 'question': question_text})
        if existing:
            flash('A question with the same text already exists for this version.', 'error')
            return redirect(url_for('add_question'))

        # Build document and insert
        doc = {
            "_id": str(ObjectId()),
            "version": version,
            "question": question_text,
            "options": options,
            "correct": correct,
            "topic": topic
        }
        collection.insert_one(doc)
        flash('Question added', 'success')
        return redirect(url_for('add_question'))

    return render_template('admin_add_question.html')


@app.route('/admin/questions')
def admin_questions():
    # require admin
    if not session.get('admin'):
        return redirect(url_for('admin_login'))

    # Fetch questions (limit to 1000 for safety)
    docs = list(collection.find().sort([('version', -1)]).limit(1000))
    # render template
    return render_template('admin_questions.html', questions=docs)

@app.route('/start_exam', methods=['POST'])
def start_exam():
    # Get form data
    num_questions = int(request.form.get('num_questions', 125))
    versions = request.form.getlist('version')
    
    # Create a filter for selected versions
    version_filter = {'version': {'$in': versions}} if versions else {}
    
    # Get random questions for selected versions
    questions = list(collection.aggregate([
        {'$match': version_filter},
        {'$sample': {'size': num_questions}}
    ]))
    
    # Initialize session data
    session['exam_started'] = datetime.now().isoformat()
    session['total_questions'] = len(questions)
    session['answered'] = []
    
    return render_template('exam.html', questions=questions)

@app.route('/verify_answer', methods=['POST'])
def verify_answer():
    data = request.get_json()
    qid = data['question_id']
    user_answer = data['user_answer']
    
    # Get question from database
    question = collection.find_one({'_id': qid})
    
    # Check answer and update session
    if question and question['correct'] == user_answer:
        result = 'correct'
    else:
        result = 'wrong'
    
    # Track answered questions if not already answered
    if qid not in session.get('answered', []):
        session['answered'] = session.get('answered', []) + [qid]
        session.modified = True

    return jsonify({
        'result': result,
        'progress': {
            'answered': len(session.get('answered', [])),
            'total': session.get('total_questions', 0)
        }
    })

@app.route('/exam_status')
def exam_status():
    if 'exam_started' not in session:
        return jsonify({'active': False})
    
    return jsonify({
        'active': True,
        'started': session['exam_started'],
        'progress': {
            'answered': len(session.get('answered', [])),
            'total': session.get('total_questions', 0)
        }
    })

@app.route('/clear_exam')
def clear_exam():
    session.clear()
    return jsonify({'status': 'success'})

if __name__ == '__main__':
    app.run(debug=True)
