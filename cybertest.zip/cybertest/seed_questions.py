from pymongo import MongoClient
from bson import ObjectId

client = MongoClient("mongodb+srv://admin:admin123@cluster0.2mcmdvo.mongodb.net/?retryWrites=true&w=majority")
db = client["cybertest_db"]
collection = db["questions"]

versions = ["12", "11", "10", "9", "8"]

questions = [
    # Network Security (1-25)
    {
        "_id": str(ObjectId()),
        "version": "12",
        "question": "Which protocol is used to securely browse websites?",
        "options": ["HTTP", "FTP", "SSH", "HTTPS"],
        "correct": "HTTPS"
    },
    # ... Add more network security questions here
    
    # System Security (26-50)
    {
        "_id": str(ObjectId()),
        "version": "11",
        "question": "Which tool is used for packet sniffing?",
        "options": ["Wireshark", "Metasploit", "Nmap", "Aircrack-ng"],
        "correct": "Wireshark"
    },
    # ... Add more system security questions here
    
    # Web Security (51-75)
    {
        "_id": str(ObjectId()),
        "version": "10",
        "question": "What does SQL stand for?",
        "options": ["Structured Query Language", "Strong Question Language", "System Query Logic", "Simple Query Line"],
        "correct": "Structured Query Language"
    },
    # ... Add more web security questions here
    
    # Cryptography (76-100)
    {
        "_id": str(ObjectId()),
        "version": "9",
        "question": "Which encryption algorithm is considered asymmetric?",
        "options": ["AES", "RSA", "DES", "3DES"],
        "correct": "RSA"
    },
    # ... Add more cryptography questions here
    
    # General Security Concepts (101-125)
    {
        "_id": str(ObjectId()),
        "version": "8",
        "question": "What is the primary goal of CIA triad in information security?",
        "options": [
            "Confidentiality, Integrity, Availability",
            "Control, Infrastructure, Access",
            "Cybersecurity, Infrastructure, Authentication",
            "Cryptography, Identity, Authorization"
        ],
        "correct": "Confidentiality, Integrity, Availability"
    }
    # ... Add more general security questions here
]

# Generate remaining questions programmatically to reach 125
base_questions = questions.copy()
# Expand base questions to reach 125, cycling versions to spread across multiple versions
i = 0
while len(questions) < 125:
    for q in base_questions:
        if len(questions) >= 125:
            break
        new_q = q.copy()
        new_q["_id"] = str(ObjectId())
        # assign version if missing by cycling through versions list
        new_q["version"] = new_q.get("version") or versions[i % len(versions)]
        i += 1
        questions.append(new_q)

collection.insert_many(questions)
print("✅ Questions added successfully!")
