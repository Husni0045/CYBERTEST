document.addEventListener('DOMContentLoaded', () => {
    // Enable continue button if exam in session (if present)
    fetch('/exam_status')
        .then(res => res.json())
        .then(data => {
            const cont = document.querySelector('.continue-button');
            if (cont && data.active) cont.disabled = false;
        })
        .catch(() => {});

    // Setup form validation and simple version selection visuals
    const setupForm = document.querySelector('.exam-setup-form');
    if (setupForm) {
        const versionInputs = setupForm.querySelectorAll('input[name="version"]');
        const versionLabels = setupForm.querySelectorAll('.version-group .version-pill');
        const versionToggle = setupForm.querySelector('.version-toggle');
        const versionGroup = setupForm.querySelector('.version-group');
        const startBtn = document.getElementById('startExamBtn');

        function updateVersionVisuals() {
            versionLabels.forEach(lbl => {
                const id = lbl.getAttribute('for');
                const inp = id ? document.getElementById(id) : lbl.previousElementSibling;
                if (inp && inp.checked) lbl.classList.add('selected'); else lbl.classList.remove('selected');
            });
        }

        versionInputs.forEach(inp => inp.addEventListener('change', updateVersionVisuals));

        // enable start button when a version is selected and update toggle text
        function onVersionSelected(ev) {
            const inp = ev.target || ev;
            if (!inp) return;
            // update toggle text to show chosen version
            const lbl = setupForm.querySelector(`label[for="${inp.id}"]`);
            if (lbl && versionToggle) versionToggle.textContent = lbl.textContent.trim();
            // enable start button
            if (startBtn) startBtn.disabled = false;
            // optionally close the selector after choice
            if (versionGroup) {
                versionGroup.hidden = true;
                if (versionToggle) versionToggle.setAttribute('aria-expanded', 'false');
            }
        }

        versionInputs.forEach(inp => inp.addEventListener('change', onVersionSelected));

        // add keyboard support to labels
        versionLabels.forEach(lbl => {
            lbl.setAttribute('tabindex', '0');
            lbl.addEventListener('keydown', (ev) => {
                if (ev.key === 'Enter' || ev.key === ' ') {
                    ev.preventDefault();
                    const id = lbl.getAttribute('for');
                    const inp = id ? document.getElementById(id) : lbl.previousElementSibling;
                    if (inp) inp.checked = true;
                    updateVersionVisuals();
                    onVersionSelected(inp);
                }
            });
        });

        // toggle button to show/hide version list
        if (versionToggle && versionGroup) {
            versionToggle.addEventListener('click', () => {
                const isOpen = !(versionGroup.hidden);
                versionGroup.hidden = isOpen; // hide if open, show if closed
                versionToggle.setAttribute('aria-expanded', String(!isOpen));
                if (!isOpen) {
                    // focus first radio for keyboard users
                    const first = setupForm.querySelector('input[name="version"]');
                    if (first) first.focus();
                }
            });
        }

        // initial sync
        updateVersionVisuals();

        setupForm.addEventListener('submit', (e) => {
            const checked = setupForm.querySelector('input[name="version"]:checked');
            if (!checked) {
                e.preventDefault();
                alert('Please select a CEH version');
            }
        });
    }

    // Exam logic
    const examArea = document.getElementById('exam-area');
    if (!examArea) return;

    const totalElem = document.getElementById('total-questions');
    const TOTAL = totalElem ? parseInt(totalElem.textContent, 10) : document.querySelectorAll('.question-card').length;

    let stats = { attempted: 0, correct: 0, incorrect: 0 };
    let resultsChart = null;

    function updateStats() {
        const attemptedEl = document.getElementById('attempted-count');
        const correctEl = document.getElementById('correct-count');
        const incorrectEl = document.getElementById('incorrect-count');
        if (attemptedEl) attemptedEl.textContent = stats.attempted;
        if (correctEl) correctEl.textContent = stats.correct;
        if (incorrectEl) incorrectEl.textContent = stats.incorrect;

        if (stats.attempted === TOTAL) showFinalResults();
    }

    function showFinalResults() {
        const resultsDiv = document.getElementById('results-chart');
        const canvas = document.getElementById('resultsChart');
        if (!resultsDiv || !canvas) return;
        resultsDiv.style.display = 'block';

        const ctx = canvas.getContext('2d');
        if (resultsChart) resultsChart.destroy();
        resultsChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Correct', 'Incorrect'],
                datasets: [{ data: [stats.correct, stats.incorrect], backgroundColor: ['#4CAF50', '#f44336'] }]
            },
            options: { responsive: true }
        });
    }

    function navigateToQuestion(number) {
        if (number < 1 || number > TOTAL) return;
        document.querySelectorAll('.question-card').forEach(card => {
            card.classList.add('hidden');
            if (parseInt(card.dataset.questionNumber, 10) === number) card.classList.remove('hidden');
        });
        document.querySelectorAll('.question-number').forEach(num => {
            num.classList.toggle('current', parseInt(num.dataset.question, 10) === number);
        });
    }

    // Wire up sidebar numbers
    document.querySelectorAll('.question-number').forEach(num => {
        num.addEventListener('click', () => navigateToQuestion(parseInt(num.dataset.question, 10)));
    });

    // Prev/Next buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const card = e.target.closest('.question-card');
            if (!card) return;
            const current = parseInt(card.dataset.questionNumber, 10);
            const next = btn.classList.contains('next-btn') ? current + 1 : current - 1;
            navigateToQuestion(next);
        });
    });

    // Answer verification
    document.querySelectorAll('.verify-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const parent = e.target.closest('.question-card');
            if (!parent) return;
            const qid = parent.dataset.id;
            const qnum = parseInt(parent.dataset.questionNumber, 10);
            const answer = parent.querySelector('input[type="radio"]:checked');
            const resultBox = parent.querySelector('.result');
            const indicator = document.querySelector(`.question-number[data-question="${qnum}"]`);

            if (!answer) { alert('Please select an answer!'); return; }
            btn.disabled = true;

            try {
                const res = await fetch('/verify_answer', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ question_id: qid, user_answer: answer.value })
                });
                const data = await res.json();
                const correct = data.result === 'correct';
                if (resultBox) resultBox.textContent = correct ? '✅ Correct!' : '❌ Wrong!';
                if (indicator) indicator.classList.add(correct ? 'correct' : 'incorrect');

                if (indicator && !indicator.classList.contains('attempted')) {
                    stats.attempted++;
                    if (correct) stats.correct++; else stats.incorrect++;
                    indicator.classList.add('attempted');
                }

                updateStats();

                const next = qnum + 1;
                if (next <= TOTAL) setTimeout(() => navigateToQuestion(next), 800);
            } catch (err) {
                console.error(err);
                if (resultBox) resultBox.textContent = '❌ Error verifying answer. Please try again.';
                btn.disabled = false;
            }
        });
    });

    // Mark first question current
    const first = document.querySelector('.question-number[data-question="1"]');
    if (first) first.classList.add('current');
});
